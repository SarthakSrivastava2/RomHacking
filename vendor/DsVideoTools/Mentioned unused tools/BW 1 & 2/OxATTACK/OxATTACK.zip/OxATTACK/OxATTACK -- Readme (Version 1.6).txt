
---------------------------------------------------------------------------------------------------------------------

			                            OxATTACK �
	   		                             
						CREATED BY OXNITE

---------------------------------------------------------------------------------------------------------------------


GENERAL INFORMATION
**************************

OxATTACK is � Oxnite.
However, I would like to thank TwistedFatal for his support (I have used his Pok�mon Stat Editor
as a base for this tool). Please leave a feedback at the place you've downloaded this tool at.

Thanks a lot for using my tool(s)!


What's new in Version 1.6?
---------------------------
	--> Move Mechanics are now editable (added in a tab system).
	--> Several new Effect descriptions have been added (eventually all effects have descriptions).
	--> Several effect descriptions are now numbered (eventually they will all be numbered).
	--> Information is now shown in a pop-up balloon when you hover over certain objects.


**************************

Oxnite
